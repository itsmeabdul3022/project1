#
import cowsay
import sys

if len(sys.argv) >= 2:
    cowsay.kitty("Hello, " + sys.argv[1] + "   Are you ready for swimming today?")
    cowsay.trex("Hello, " + sys.argv[2] + " Are you ready for swimming today?")
    cowsay.stegosaurus("Hello, " + sys.argv[3] + " Are you ready for swimming today?")
    cowsay.fox("Hello, " + sys.argv[4] + " Are you ready for swimming today?")
    cowsay.stimpy("Hello, " + sys.argv[5] + " Are you ready for swimming today?")
    cowsay.milk("Hello, " + sys.argv[6] + " Are you ready for swimming today?")
    cowsay.turkey("Hello, " + sys.argv[7] + " Are you ready for swimming today?")
