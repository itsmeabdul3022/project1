# using file 
names = []
for n in range(2):
    name = input("What is your name ? ")
    names.append(name)
print(f"Hello, {names}")

