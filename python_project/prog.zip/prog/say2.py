import sys
import cowsay

a = input("Enter your name \n")
b = input("Enter your name \n")

cowsay.cow("Hello", a)
cowsay.trex("Hello", b)
